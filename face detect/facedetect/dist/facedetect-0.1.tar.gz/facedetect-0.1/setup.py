from setuptools import setup
setup(name="facedetect",
      version="0.1",
      description="this is face detection module",
      long_description="face detection module will help us to detect faces and as well as emotions. then baased on those emotions we will be able to change the color of text entered by the user.",
      author="Malay",
      packages=['facedetect'],
      install_requires=[])
